import streamlit as st
import pandas as pd
import json
from pathlib import Path

st.title("Agriculture × Climate QA Prototype – Option 1")

# load sample
crop = pd.read_csv(Path("data/sample/crop_production_sample.csv"))
with open("data/sample/imd_district_rainfall.json") as f:
    rain = json.load(f)["data"]

rain_df = pd.DataFrame(rain)

st.write("### Ask a question")
q = st.text_input("Example: compare rainfall Karnataka vs Maharashtra last 1 year and top 1 crops")

if q:
    # simple static demo logic: only Karnataka supported in sample
    avg_rain = rain_df["rainfall"].mean()
    top_crop = crop.groupby("crop_name")["production_tonnes"].sum().idxmax()
    st.write("### Answer")
    st.write(f"Karnataka avg rainfall (sample): {avg_rain} mm  — source: IMD sample")
    st.write(f"Top produced crop: {top_crop} — source: Agri Production sample")

    st.success("End‑to‑end response generated ✔")

st.caption("this is a minimal functional proto")
